package data;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the fish database table.
 * 
 */
@Entity
@NamedQuery(name="Fish.findAll", query="SELECT f FROM Fish f")
public class Fish implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String breed;

	private Float weight;

	//bi-directional many-to-one association to Kid
	@ManyToOne
	private Kid kid;

	//bi-directional many-to-one association to Lure
	@ManyToOne
	private Lure lure;

	public Fish() {
	}

	public Fish(String breed, String weight) {
		this.breed=breed;
		try {
			this.weight=Float.parseFloat(weight);
		}
		catch(NumberFormatException | NullPointerException e) {
			
		}
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBreed() {
		return this.breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public Float getWeight() {
		return this.weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}

	public Kid getKid() {
		return this.kid;
	}

	public void setKid(Kid kid) {
		this.kid = kid;
	}

	public Lure getLure() {
		return this.lure;
	}

	public void setLure(Lure lure) {
		this.lure = lure;
	}
	public boolean isOk() {
		return this.breed!=null && this.weight>0;
	}
	public String toString() {
		return "Fish: "+this.id+"/"+this.breed+"/"+this.weight;
	}
}