package data;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the kid database table.
 * 
 */
@Entity
@NamedQuery(name="Kid.findAll", query="SELECT k FROM Kid k")
public class Kid implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String name;

	//bi-directional many-to-one association to Fish
	@OneToMany(mappedBy="kid")
	private List<Fish> fishs;

	public Kid() {
	}

	public Kid(String name) {
		this.name=name;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public void setId(String id) {
		try {
			this.id=Integer.parseInt(id);
		}
		catch(NumberFormatException e) {
			
		}
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Fish> getFishs() {
		return this.fishs;
	}

	public void setFishs(List<Fish> fishs) {
		this.fishs = fishs;
	}

	public Fish addFish(Fish fish) {
		getFishs().add(fish);
		fish.setKid(this);
		return fish;
	}

	public Fish removeFish(Fish fish) {
		getFishs().remove(fish);
		fish.setKid(null);

		return fish;
	}
	public String toString() {
		return "Kid: "+this.id+"/"+this.name;
	}
}