package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.Fish;
import data.Kid;
import data.Lure;

/**
 * Servlet implementation class Queries
 */
@WebServlet("/queries")
public class Queries extends HttpServlet {
	private static final long serialVersionUID = 1L;
    EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpaqueries");
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Queries() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		selectAllKids(out);
		selectAllLures(out);
		selectAllFish(out);
		selectKidsStartingWith(out, "J");
		selectKidsStartingWith(out, "T");
		selectPositionParKidsStartingWith(out, "J");
		selectPositionParKidsStartingWith(out, "T");
		selectFishGreaterThan(out, 1000);
	}

	private void selectFishGreaterThan(PrintWriter out, int someWeight) {
		out.println("<h3>Fish greater than "+someWeight+"</h3>");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		List<Fish> list=em.createQuery("select k from Fish k where k.weight>?1").setParameter(1, someWeight).getResultList();
		em.getTransaction().commit();
		em.close();
		printFish(out, list);
	}

	private void selectKidsStartingWith(PrintWriter out, String letter) {
		out.println("<h3>Kids starting with "+letter+" - using named parameter</h3>");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Query q=em.createQuery("select k from Kid k where k.name like :name");
		q.setParameter("name", letter+"%");
		List<Kid> list=q.getResultList();
		em.getTransaction().commit();
		em.close();
		printKids(out, list);
	}
	private void selectPositionParKidsStartingWith(PrintWriter out, String letter) {
		out.println("<h3>Kids starting with "+letter+" - using position parameter</h3>");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		Query q=em.createQuery("select k from Kid k where k.name like ?1").setParameter(1, letter+"%");
		List<Kid> list=q.getResultList();
		em.getTransaction().commit();
		em.close();
		printKids(out, list);
	}

	private void selectAllKids(PrintWriter out) {
		out.println("<h3>All kids</h3>");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		List<Kid> list=em.createQuery("select k from Kid k").getResultList();
		em.getTransaction().commit();
		em.close();
		printKids(out, list);
		printKidsAndAll(out, list);
	}
	private void printKids(PrintWriter out, List<Kid> list) {
		// TODO Auto-generated method stub
		for (int i=0;list!=null && i<list.size();i++) {
			Kid k=list.get(i);
			out.println(k+"<br>");
		}
	}

	private void printKidsAndAll(PrintWriter out, List<Kid> list) {
		// TODO Auto-generated method stub
		out.println("<h3>All kids plus caught fish by certain lure</h3>");
		for (int i=0;list!=null && i<list.size();i++) {
			Kid k=list.get(i);
			out.println(k+"<br>");
			for (Fish f : k.getFishs()) {
				out.println(f+" caught by lure "+f.getLure()+"<br>");
			}
		}
	}

	private void selectAllLures(PrintWriter out) {
		out.println("<h3>All lures</h3>");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		List<Lure> list=em.createQuery("select k from Lure k").getResultList();
		em.getTransaction().commit();
		em.close();
		printLures(out, list);
	}

	private void printLures(PrintWriter out, List<Lure> list) {
		// TODO Auto-generated method stub
		for (int i=0;list!=null && i<list.size();i++) {
			Lure k=list.get(i);
			out.println(k+"<br>");
		}
	}

	private void selectAllFish(PrintWriter out) {
		out.println("<h3>All fish</h3>");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		List<Fish> list=em.createQuery("select k from Fish k").getResultList();
		em.getTransaction().commit();
		em.close();
		printFish(out, list);
	}

	private void printFish(PrintWriter out, List<Fish> list) {
		// TODO Auto-generated method stub
		for (int i=0;list!=null && i<list.size();i++) {
			Fish k=list.get(i);
			out.println(k+"<br>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
