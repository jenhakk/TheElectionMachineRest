package data;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the lure database table.
 * 
 */
@Entity
@NamedQuery(name="Lure.findAll", query="SELECT l FROM Lure l")
public class Lure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private String type;

	//bi-directional many-to-one association to Fish
	@OneToMany(mappedBy="lure")
	private List<Fish> fishs;

	public Lure() {
	}

	public Lure(String type) {
		// TODO Auto-generated constructor stub
		this.type=type;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setId(String id) {
		try {
			this.id=Integer.parseInt(id);
		}
		catch(NumberFormatException e) {
			
		}
	}
	
	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Fish> getFishs() {
		return this.fishs;
	}

	public void setFishs(List<Fish> fishs) {
		this.fishs = fishs;
	}

	public Fish addFish(Fish fish) {
		getFishs().add(fish);
		fish.setLure(this);

		return fish;
	}

	public Fish removeFish(Fish fish) {
		getFishs().remove(fish);
		fish.setLure(null);

		return fish;
	}
	public String toString() {
		return "Lure: "+this.id+"/"+this.type;
	}
}