package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.Fish;
import data.Kid;
import data.Lure;

@WebServlet(
    name = "Addfish",
    urlPatterns = {"/addfish"}
)
public class Addfish extends HttpServlet {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpaqueries");
  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out=response.getWriter();
		printForm(out);
		EntityManager em=emf.createEntityManager();
		String breed=request.getParameter("breed");
		String weight=request.getParameter("weight");
		Fish fish=new Fish(breed, weight);
		String kid=request.getParameter("kid");
		String lure=request.getParameter("lure");
		Kid k=new Kid();
		k.setId(kid);
		fish.setKid(k);
		Lure l=new Lure();
		l.setId(lure);
		fish.setLure(l);
		if (fish.isOk()) {
			em.getTransaction().begin();
			em.persist(fish);
			em.getTransaction().commit();
		}
		em.close();
		em=emf.createEntityManager();
		List<Kid> list=em.createQuery("select a from Kid a").getResultList();
		if (list!=null) {
			out.println("<h2>Kids</h2>");
			for (Kid x:list) {
				out.println(x.getName()+"<br>");
			}
		}
		else {
			out.println("<h3>Kid list is empty</h3>");
		}
		List<Lure> lureList=em.createQuery("select a from Lure a").getResultList();
		if (lureList!=null) {
			out.println("<h2>Lures</h2>");
			for (Lure x:lureList) {
				out.println(x.getType()+"<br>");
			}
		}
		else {
			out.println("<h3>Lure list is empty</h3>");
		}
		em.getTransaction().begin();
		List<Fish> fishList=em.createQuery("select a from Fish a").getResultList();
		em.getTransaction().commit();
		if (fishList!=null) {
			out.println("<h2>Fish</h2>");
			for (Fish x:fishList) {
				out.println(x.getBreed()+" / "+x.getWeight().shortValue()+" / "+x.getKid().getName()+ " / "+x.getLure().getType()+"<br>");
			}
		}
		else {
			out.println("<h3>Lure list is empty</h3>");
		}
  }
	private void printForm(PrintWriter out) {
		EntityManager em=emf.createEntityManager();
		List<Kid> kidlist=em.createQuery("select a from Kid a").getResultList();
		List<Lure> lurelist=em.createQuery("select a from Lure a").getResultList();
		
		out.println("<form action='addfish' mathod='get'</form>");
		out.println("Fish breed: <input type='text' name='breed' value=''><br>");
		out.println("Fish weight: <input type='text' name='weight' value=''><br>");
		out.println("Kid: <select name='kid'>");
		for (Kid kid:kidlist) {
			out.println("<option value='"+kid.getId()+"'>"+kid.getName());
		}
		out.println("</select><br>");
		out.println("Lure: <select name='lure'>");
		for (Lure lure:lurelist) {
			out.println("<option value='"+lure.getId()+"'>"+lure.getType());
		}
		out.println("</select><br>");
		out.println("<input type='submit' name='ok' value='OK'><br>");
		out.println("</form>");
		
	}
}