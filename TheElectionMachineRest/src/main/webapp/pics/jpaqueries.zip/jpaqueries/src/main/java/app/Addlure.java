package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.Lure;

@WebServlet(
    name = "Addlure",
    urlPatterns = {"/addlure"}
)
public class Addlure extends HttpServlet {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpaqueries");
  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out=response.getWriter();
		EntityManager em=emf.createEntityManager();
		String s=request.getParameter("lure");
		if (s!=null) {
			Lure lure=new Lure(s);
			em.getTransaction().begin();
			em.persist(lure);
			em.getTransaction().commit();
		}
	
		List<Lure> list=em.createQuery("select a from Lure a").getResultList();
		if (list==null) {
			out.println("<h3>Empty set</h3>");
		}
		for (Lure lure:list) {
			out.println(lure.getType()+"<br>");
		}
  }
}