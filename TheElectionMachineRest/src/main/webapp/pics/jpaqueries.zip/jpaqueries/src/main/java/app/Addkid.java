package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.Kid;
import data.Lure;

@WebServlet(
    name = "Addkid",
    urlPatterns = {"/addkid"}
)
public class Addkid extends HttpServlet {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpaqueries");
  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out=response.getWriter();
		EntityManager em=emf.createEntityManager();
		String s=request.getParameter("name");
		if (s!=null) {
			Kid kid=new Kid(s);
			em.getTransaction().begin();
			em.persist(kid);
			em.getTransaction().commit();
		}
		List<Kid> list=em.createQuery("select a from Kid a").getResultList();
		if (list==null) {
			out.println("<h3>Empty set</h3>");
		}
		for (Kid kid:list) {
			out.println(kid.getName()+"<br>");
		}
  }
}