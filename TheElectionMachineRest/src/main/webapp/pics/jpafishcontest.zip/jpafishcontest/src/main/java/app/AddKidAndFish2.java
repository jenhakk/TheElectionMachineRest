package app;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.*;

@WebServlet("/addkidandfish2")
public class AddKidAndFish2 extends HttpServlet {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpafishcontest");
  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {
	  Kid kid=new Kid("Joe");
	    Fish f1=new Fish("Rainbow trout");
	    kid.addFish(f1);
	    Fish f2=new Fish("Sterlet");
	    kid.addFish(f2);
	    Fish f3=new Fish("Bleak");
	    kid.addFish(f3);
	    
	    EntityManager em=emf.createEntityManager();
	    em.getTransaction().begin();
	    em.persist(kid);
	    em.getTransaction().commit();
  }
}
