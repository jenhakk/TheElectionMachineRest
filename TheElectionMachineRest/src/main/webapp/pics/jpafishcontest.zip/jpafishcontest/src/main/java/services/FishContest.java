package services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import data.Kid;

@Path("/fishcontest")
public class FishContest {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpafishcontest");

	
	@GET
	@Path("/getkids")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Kid> getKids(){
	    EntityManager em=emf.createEntityManager();
	    em.getTransaction().begin();
	    List<Kid> list=em.createQuery("select a from Kid a").getResultList();
	    em.getTransaction().commit();
		return list;
	}
}
