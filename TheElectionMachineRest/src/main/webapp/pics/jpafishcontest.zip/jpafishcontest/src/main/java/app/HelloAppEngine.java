package app;

import java.io.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import data.*;

@WebServlet(
    name = "HelloAppEngine",
    urlPatterns = {"/hello"}
)
public class HelloAppEngine extends HttpServlet {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpafishcontest");
  @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) 
      throws IOException {

    response.setContentType("text/plain");
    response.setCharacterEncoding("UTF-8");
    PrintWriter out=response.getWriter();
    out.print("Hello App Engine!\r\n");
    
    Kid kid=new Kid("Bill");
    Fish f=new Fish("Salmon", kid);
    kid.addFish(f);
    f=new Fish("Trout", kid);
    kid.addFish(f);
    f=new Fish("Pike", kid);
    kid.addFish(f);
    
    EntityManager em=emf.createEntityManager();
    em.getTransaction().begin();
    em.persist(kid);
    em.getTransaction().commit();
  }
}