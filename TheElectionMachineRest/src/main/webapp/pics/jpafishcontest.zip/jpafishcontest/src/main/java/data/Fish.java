package data;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Fish {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String breed;
	
	//bi-directional many-to-one association to Kid
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JsonBackReference //To handle converting object to JSON and backwards
	@JoinColumn(name="kidid")
	private Kid kid;
	
	public Fish() {
		
	}
	public Fish(String breed) {
		this.breed=breed;
	}
	public Fish(String breed, Kid kid) {
		this.breed=breed;
		this.kid=kid;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setId(String id) {
		try {
			this.id = Integer.parseInt(id);
		}
		catch(NumberFormatException | NullPointerException e) {
			//Do nothing
		}
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	
	public Kid getKid() {
		return this.kid;
	}

	public void setKid(Kid kid) {
		this.kid = kid;
	}
	
	public String toString() {
		return id+": "+breed+" / "+kid.getName();
	}
}
