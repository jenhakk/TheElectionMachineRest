package data;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Kid {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;

	//bi-directional many-to-one association to Fish
	@OneToMany(mappedBy="kid", fetch=FetchType.LAZY, cascade = CascadeType.PERSIST)
	@JsonManagedReference //To handle converting object to JSON and backwards
	private List<Fish> fishlist;
	
	public Kid() {
		
	}
	public Kid(String name) {
		this.name=name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setId(String id) {
		try {
			this.id = Integer.parseInt(id);
		}
		catch(NumberFormatException | NullPointerException e) {
			//Do nothing
		}
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public List<Fish> getFishlist() {
		if (this.fishlist==null) {
			fishlist=new ArrayList<>();
		}
		return this.fishlist;
	}

	public void setFishlist(List<Fish> fishlist) {
		this.fishlist = fishlist;
	}

	public Fish addFish(Fish fish) {
		getFishlist().add(fish);
		fish.setKid(this);

		return fish;
	}

	public Fish removeFish(Fish fish) {
		getFishlist().remove(fish);
		fish.setKid(null);
		return fish;
	}
	
	
	public String toString() {
		String flist="";
		for (int i=0;fishlist!=null && i<fishlist.size();i++) {
			flist=flist+fishlist.get(i)+"<br>";
		}
		return id+": "+name+" <br>The catch:<br> "+flist;
	}
}
